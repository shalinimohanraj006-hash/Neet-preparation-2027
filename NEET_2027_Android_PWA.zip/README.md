# NEET 2027 PWA

This is an installable Android PWA.

IMPORTANT: A PWA must be opened from an HTTPS web address (or localhost during development) for service-worker installation. Opening index.html directly from the Downloads folder will not make it installable.

## Easiest Android installation
1. Host this folder on an HTTPS static hosting service.
2. Open the HTTPS URL in Chrome on Android.
3. Tap Chrome's ⋮ menu.
4. Choose "Add to Home screen" or "Install app".
5. Confirm.
6. Launch "NEET 2027" from the home screen.

The app stores study data locally in the browser/device.

## Local testing
Use a computer:
python -m http.server 8000
Then open http://localhost:8000 from a device that can reach the computer.

For real Android installation, use HTTPS hosting.
